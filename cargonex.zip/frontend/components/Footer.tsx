// Footer.tsx - placeholder for CARGONEX
