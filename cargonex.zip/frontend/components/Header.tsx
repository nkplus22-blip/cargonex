// Header.tsx - placeholder for CARGONEX
