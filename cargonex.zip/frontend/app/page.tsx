// page.tsx - placeholder for CARGONEX
